=== Cream Blog Lite ===

Contributors: themebeez
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, left-sidebar, right-sidebar, news, blog, custom-header, theme-options, footer-widgets, sticky-post, grid-layout, two-columns, three-columns
Requires at least: 5.0.0
Requires PHP: 7.0.0
Tested up to: 5.7
Stable tag: 1.0.2
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cream Blog Lite is a child theme of WordPress theme, Cream Blog.


== Description ==
Cream Blog Lite is a child theme of WordPress theme, Cream Blog. Cream Blog Lite is clean, responsive, user friendly and easily customizable. Cream Blog Lite is light weight and can be used to create and run magazine, blog and other online publishing websites. With one click demo import, it is easy to setup your website. Cream Blog Lite is translation ready. For demos and more information visit, https://themebeez.com/themes/cream-blog-lite.


== License ==

Cream Blog Lite WordPress Theme, Copyright (C) 2021, themebeez.
Cream Blog Lite is distributed under the terms of the GNU GPLv2 or later

Cream Blog WordPress Theme, Copyright (C) 2021, themebeez.
Cream Blog is distributed under the terms of the GNU GPLv2 or later.


== Screenshots ==

White table
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/1445341


Smiling lady
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/1389875


Romantic couple
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/807588


Family at beach
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
https://pxhere.com/en/photo/1364702




== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Changelog ==

= 1.0.2 - 9 April, 2021 =

- HTML tag for post title in single changed to <h1>

= 1.0.1 - 10, Sept 2020 =

- Fix: Font size
- Fix: Banner arrow

= 1.0.0 - 6, May 2019 =

- Initial release
